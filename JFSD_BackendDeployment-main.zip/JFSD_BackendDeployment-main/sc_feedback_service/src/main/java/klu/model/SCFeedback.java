package klu.model;

import jakarta.persistence.*;

@Entity
@Table(name = "student_course_feedback")
public class SCFeedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    @Column(name = "feedback", nullable = true, length = 1000) // Feedback can be empty
    private String feedback;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    @Override
    public String toString() {
        return "SCFeedback{" +
                "id=" + id +
                ", student=" + student +
                ", course=" + course +
                ", feedback='" + feedback + '\'' +
                '}';
    }
}
