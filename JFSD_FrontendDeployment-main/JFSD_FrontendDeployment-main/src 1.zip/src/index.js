import React from 'react';
import ReactDOM from 'react-dom/client'; // Use 'react-dom/client' for React 18
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './index.css';
import Login from './login';
import AddAdmin from './AddAdmin';
import ViewAdmins from './viewAdmins';
import AdminHome from './AdminHome';
import ViewStudents from './ViewStudents';
import UpdateStudent from './UpdateStudent';
import AddStudent from './AddStudent';
import ViewFaculty from './ViewFaculty';
import UpdateFaculty from './UpdateFaculty';
import AddFaculty from './AddFaculty';
import ViewCourses from './ViewCourses';
import UpdateCourses from './UpdateCourse';
import AddCourse from './AddCourse';
import AddStudentCourse from './AddStudentCourse';
import ViewStudentCourse from './ViewStudentCourse';
import UpdateStudentCourse from './UpdateStudentCourse';
function Website() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path='/addAdmin' element={<AddAdmin />} />
                <Route path='/viewAdmins' element={<ViewAdmins />} />
                <Route path='/adminHome' element={<AdminHome />} />
                <Route path="/students/view" element={<ViewStudents />} />
                <Route path="/students/update" element={<UpdateStudent />} />
                <Route path="/students/add" element={<AddStudent />} />
                <Route path="/faculty/view" element={<ViewFaculty />} />
                <Route path="/faculty/update" element={<UpdateFaculty />} />
                <Route path="/faculty/add" element={<AddFaculty />} />
                <Route path="/courses/view" element={<ViewCourses />} />
                <Route path="/courses/update" element={<UpdateCourses />} />
                <Route path="/courses/add" element={<AddCourse />} />
                <Route path="/student-course-mapping/add" element={<AddStudentCourse />} />
                <Route path="/student-course-mapping/view" element={<ViewStudentCourse />} />
                <Route path="/student-course-mapping/update" element={<UpdateStudentCourse />} />
            </Routes>
        </BrowserRouter>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Website />);