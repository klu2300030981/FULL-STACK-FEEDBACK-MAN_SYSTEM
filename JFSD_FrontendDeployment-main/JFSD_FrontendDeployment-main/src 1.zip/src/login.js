import React from 'react';
import { callApi } from './main';
import './login.css';
class Login extends React.Component {
    constructor() {
        super();
        this.state = { id: '', password: '', errorMessage: '' };
        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleLogin = this.handleLogin.bind(this);
    }

    handleInputChange(event) {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    }

    handleLogin(event) {
        event.preventDefault(); // Prevent form from refreshing the page
        const { id, password } = this.state;

        // Updated URL to get admin details by ID
        const url = `http://localhost:2002/admins/${id}`;

        callApi(
            'GET',
            url,
            null,
            (res) => {
                const admin = JSON.parse(res);

                // Check if the password matches
                if (admin.password === password) {
                    // Store admin details in session storage
                    sessionStorage.setItem('isLoggedIn', 'true');
                    sessionStorage.setItem('adminId', admin.id);
                    sessionStorage.setItem('adminName', admin.name);
                    sessionStorage.setItem('adminEmailId', admin.emailId);

                    // Redirect to admin home page on successful login
                    window.location.href = "/adminhome";
                } else {
                    this.setState({ errorMessage: 'Invalid Password. Please try again.' });
                }
            },
            (err) => {
                console.error(err);
                this.setState({ errorMessage: 'Admin ID not found or service is unavailable.' });
            }
        );
    }

    render() {
        const { id, password, errorMessage } = this.state;
        return (
            <div className='login-container'>
                <h2>Admin Login</h2>
                <form onSubmit={this.handleLogin}>
                    <div className='form-group'>
                        <label htmlFor='id'>ID</label>
                        <input
                            type='text'
                            id='id'
                            name='id'
                            value={id}
                            onChange={this.handleInputChange}
                            required
                        />
                    </div>
                    <div className='form-group'>
                        <label htmlFor='password'>Password</label>
                        <input
                            type='password'
                            id='password'
                            name='password'
                            value={password}
                            onChange={this.handleInputChange}
                            required
                        />
                    </div>
                    {errorMessage && <p className='error'>{errorMessage}</p>}
                    <button type='submit'>Login</button>
                </form>
            </div>
        );
    }
}

export default Login;
