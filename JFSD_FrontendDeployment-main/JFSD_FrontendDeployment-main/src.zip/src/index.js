import React from 'react';
import ReactDOM from 'react-dom/client'; // Use 'react-dom/client' for React 18
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './index.css';
import Login from './login';
import AddAdmin from './AddAdmin';
import ViewAdmins from './viewAdmins';
import AdminHome from './AdminHome';
function Website() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path='/addAdmin' element={<AddAdmin />} />
                <Route path='/viewAdmins' element={<ViewAdmins />} />
                <Route path='/adminHome' element={<AdminHome />} />
            </Routes>
        </BrowserRouter>
    );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Website />);