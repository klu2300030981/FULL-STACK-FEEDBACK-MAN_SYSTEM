import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './adminhome.css';

function AdminHome() {
    const navigate = useNavigate();
    const [adminDetails, setAdminDetails] = useState(null);
    const [expandedMenu, setExpandedMenu] = useState(null);

    useEffect(() => {
        const isLoggedIn = sessionStorage.getItem('isLoggedIn');
        const adminId = sessionStorage.getItem('adminId');
        const adminName = sessionStorage.getItem('adminName');
        const adminEmailId = sessionStorage.getItem('adminEmailId');

        if (!isLoggedIn || !adminId) {
            navigate('/login');
        } else {
            setAdminDetails({
                id: adminId,
                name: adminName,
                emailId: adminEmailId,
            });
        }
    }, [navigate]);

    const handleLogout = () => {
        sessionStorage.clear();
        navigate('/login');
    };

    const toggleMenu = (menu) => {
        setExpandedMenu(expandedMenu === menu ? null : menu);
    };

    return (
        <div className={styles['admin-home']}>
            <header className={styles.header}>
                <h1>Student Feedback Evaluation System</h1>
            </header>

            <nav className={styles.navbar}>
                <ul>
                    <li>
                        <button onClick={() => toggleMenu('students')}>Students</button>
                        {expandedMenu === 'students' && (
                            <ul className={styles.submenu}>
                                <li><a href="/students/add">Add</a></li>
                                <li><a href="/students/update">Update</a></li>
                                <li><a href="/students/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button onClick={() => toggleMenu('faculty')}>Faculty</button>
                        {expandedMenu === 'faculty' && (
                            <ul className={styles.submenu}>
                                <li><a href="/faculty/add">Add</a></li>
                                <li><a href="/faculty/update">Update</a></li>
                                <li><a href="/faculty/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button onClick={() => toggleMenu('courses')}>Courses</button>
                        {expandedMenu === 'courses' && (
                            <ul className={styles.submenu}>
                                <li><a href="/courses/add">Add</a></li>
                                <li><a href="/courses/update">Update</a></li>
                                <li><a href="/courses/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button onClick={() => toggleMenu('faculty-course-mapping')}>
                            Faculty-Course Mapping
                        </button>
                        {expandedMenu === 'faculty-course-mapping' && (
                            <ul className={styles.submenu}>
                                <li><a href="/faculty-course-mapping/add">Add</a></li>
                                <li><a href="/faculty-course-mapping/update">Update</a></li>
                                <li><a href="/faculty-course-mapping/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button onClick={() => toggleMenu('student-course-mapping')}>
                            Student-Course Mapping
                        </button>
                        {expandedMenu === 'student-course-mapping' && (
                            <ul className={styles.submenu}>
                                <li><a href="/student-course-mapping/add">Add</a></li>
                                <li><a href="/student-course-mapping/update">Update</a></li>
                                <li><a href="/student-course-mapping/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li><a href="/profile">My Profile</a></li>
                    <li>
                        <button 
                            onClick={handleLogout} 
                            className={styles['logout-button']}
                        >
                            Logout
                        </button>
                    </li>
                </ul>
            </nav>

            <main className={styles.content}>
                {adminDetails ? (
                    <div className={styles['admin-details']}>
                        <h2>Admin Details</h2>
                        <p><strong>ID:</strong> {adminDetails.id}</p>
                        <p><strong>Name:</strong> {adminDetails.name}</p>
                        <p><strong>Email:</strong> {adminDetails.emailId}</p>
                    </div>
                ) : (
                    <p>Loading admin details...</p>
                )}
            </main>

            <footer className={styles.footer}>
                <p>© 2024 Student Feedback Evaluation System. All rights reserved.</p>
            </footer>
        </div>
    );
}

export default AdminHome;