import React, { useState, useEffect } from 'react';
import { callApi } from './main';

function ViewAdmins() {
    const [admins, setAdmins] = useState([]);
    const [errorMessage, setErrorMessage] = useState('');

    useEffect(() => {
        // Fetch all admins data when the component is mounted
        const fetchAdmins = () => {
            const url = 'http://localhost:2002/admins'; // Backend endpoint to get all admins

            callApi(
                'GET',
                url,
                null,
                (response) => {
                    const data = JSON.parse(response); // Parse the response to JSON
                    setAdmins(data); // Update the state with admin data
                },
                (error) => {
                    console.error('Error fetching admins:', error);
                    setErrorMessage('Failed to load admin data. Please try again later.');
                }
            );
        };

        fetchAdmins();
    }, []); 
    return (
        <div className="view-admins-container">
            <h2>Admin List</h2>
            {errorMessage ? (
                <p className="error-message">{errorMessage}</p>
            ) : (
                <table className="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                        {admins.map((admin) => (
                            <tr key={admin.id}>
                                <td>{admin.id}</td>
                                <td>{admin.name}</td>
                                <td>{admin.emailId}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
}

export default ViewAdmins;
