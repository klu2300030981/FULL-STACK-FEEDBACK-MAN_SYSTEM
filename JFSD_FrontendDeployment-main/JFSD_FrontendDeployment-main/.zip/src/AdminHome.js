import React, { useEffect, useState } from 'react';
import { Route, Routes, useNavigate } from 'react-router-dom';
import './adminhome.css';
import ViewStudents from './ViewStudents';
import UpdateStudent from './UpdateStudent';
import AddStudent from './AddStudent';
import ViewFaculty from './ViewFaculty';
import UpdateFaculty from './UpdateFaculty';
import AddFaculty from './AddFaculty';
import ViewCourses from './ViewCourses';
import UpdateCourses from './UpdateCourse';
import AddCourse from './AddCourse';
import { getAdminName } from './main'; // Import the function

function AdminHome() {
    const navigate = useNavigate();
    const [expandedMenu, setExpandedMenu] = useState(null);

    useEffect(() => {
        const isLoggedIn = sessionStorage.getItem('isLoggedIn');
        const adminId = sessionStorage.getItem('adminId');
        const adminName = getAdminName(); // Get the admin name from sessionStorage

        if (!isLoggedIn || !adminId || !adminName) {
            navigate('/login');
        }
    }, [navigate]);

    const handleLogout = () => {
        sessionStorage.clear();
        navigate('/login');
    };

    const toggleMenu = (menu) => {
        setExpandedMenu(expandedMenu === menu ? null : menu);
    };

    return (
        <div className="admin-home">
            <header className="header">
                <h1>Student Feedback Evaluation System</h1>
                <div className="admin-welcome">
                    Welcome, {getAdminName()}
                </div>
            </header>

            <nav className="navbar">
                <ul>
                    <li>
                        <button onClick={() => toggleMenu('students')}>Students</button>
                        {expandedMenu === 'students' && (
                            <ul className="submenu">
                                <li><a href="/students/add">Add</a></li>
                                <li><a href="/students/update">Update</a></li>
                                <li><a href="/students/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button onClick={() => toggleMenu('faculty')}>Faculty</button>
                        {expandedMenu === 'faculty' && (
                            <ul className="submenu">
                                <li><a href="/faculty/add">Add</a></li>
                                <li><a href="/faculty/update">Update</a></li>
                                <li><a href="/faculty/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button onClick={() => toggleMenu('courses')}>Courses</button>
                        {expandedMenu === 'courses' && (
                            <ul className="submenu">
                                <li><a href="/courses/add">Add</a></li>
                                <li><a href="/courses/update">Update</a></li>
                                <li><a href="/courses/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button onClick={() => toggleMenu('faculty-course-mapping')}>
                            Faculty-Course Mapping
                        </button>
                        {expandedMenu === 'faculty-course-mapping' && (
                            <ul className="submenu">
                                <li><a href="/faculty-course-mapping/add">Add</a></li>
                                <li><a href="/faculty-course-mapping/update">Update</a></li>
                                <li><a href="/faculty-course-mapping/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button onClick={() => toggleMenu('student-course-mapping')}>
                            Student-Course Mapping
                        </button>
                        {expandedMenu === 'student-course-mapping' && (
                            <ul className="submenu">
                                <li><a href="/student-course-mapping/add">Add</a></li>
                                <li><a href="/student-course-mapping/update">Update</a></li>
                                <li><a href="/student-course-mapping/view">View</a></li>
                            </ul>
                        )}
                    </li>
                    <li>
                        <button>
                            <a href="/profile">My Profile</a>
                        </button>
                    </li>
                    <li>
                        <button 
                            onClick={handleLogout} 
                            className="logout-button"
                        >
                            Logout
                        </button>
                    </li>
                </ul>
            </nav>

            <main className="content">
                {/* Define Routes for Admin Home */}
                <Routes>
                    <Route path="/students/view" element={<ViewStudents />} />
                    <Route path="/students/update" element={<UpdateStudent />} />
                    <Route path="/students/add" element={<AddStudent />} />
                    <Route path="/faculty/view" element={<ViewFaculty />} />
                    <Route path="/faculty/update" element={<UpdateFaculty />} />
                    <Route path="/faculty/add" element={<AddFaculty />} />
                    <Route path="/courses/view" element={<ViewCourses />} />
                    <Route path="/courses/update" element={<UpdateCourses />} />
                    <Route path="/courses/add" element={<AddCourse />} />
                </Routes>
            </main>

            <footer className="footer">
                <p>© 2024 Student Feedback Evaluation System. All rights reserved.</p>
            </footer>
        </div>
    );
}

export default AdminHome;
